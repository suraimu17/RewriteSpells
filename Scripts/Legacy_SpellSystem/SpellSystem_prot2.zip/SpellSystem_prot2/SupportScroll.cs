using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//�T�|�[�g�p�̃R���|�[�l���g
public class SupportScroll : MonoBehaviour
{
    //�C���X�y�N�^�p�����[�^ �ÓI
    [Header("Parameter")]
    [SerializeField] private int _addLevel;
    [SerializeField] private float _addDelay;
    [SerializeField] private float _addManaCost;
    [SerializeField] private int _addTriggerCount;

    //�ǉ��R���g���[���[
    [Header("Controller")]
    [SerializeField] private SpellObjectController _addController;
    [SerializeField] private SpellObjectControllerType _addControllerType;

    //����
    [Header("Condtion")]
    [SerializeField] private SpellObjectType _spellObjectType;



    //�Q�Ɨp
    public int addLevel => _addLevel;
    public float addDelay => _addDelay;
    public float addManaCost => _addManaCost;
    public int addTtriggerCount => _addTriggerCount;
    public SpellObjectController addController => _addController;
    public SpellObjectControllerType addControllerType => _addControllerType;
    public SpellObjectType spellObjectType => _spellObjectType;
}
