using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrollsLoader
{
    //�p�X
    private const string SPELL_FOLDER_NAME = "Spells";
    private const string SUPPORT_FOLDER_NAME = "Supports";

    //�Ǘ��pDic
    private Dictionary<string, SpellScroll> spellDic;
    private Dictionary<string, SupportScroll> supportDic;

    //�V���O���g��
    private static ScrollsLoader _loader;
    public static ScrollsLoader loader
    {
        get
        {
            return _loader != null ? _loader : _loader = new ScrollsLoader();
        }
    }

    //�R���X�g���N�^�ŃA�Z�b�g�ǂݍ���
    private ScrollsLoader()
    {
        //�X�y�����[�h
        spellDic = new Dictionary<string, SpellScroll>();
        Object[] o_spell = Resources.LoadAll(SPELL_FOLDER_NAME, typeof(SpellScroll));
        foreach (SpellScroll spell in o_spell)
        {
            spellDic.Add(spell.name, spell);
            Debug.Log(spell.name + " is Loaded");
        }

        //�T�|�[�g���[�h
        supportDic = new Dictionary<string, SupportScroll>();
        Object[] o_support = Resources.LoadAll(SUPPORT_FOLDER_NAME, typeof(SupportScroll));
        foreach (SupportScroll support in o_support)
        {
            supportDic.Add(support.name, support);
            Debug.Log(support.name + " is Loaded");
        }
    }



    //ID�ɂ��X�y���A�T�|�[�g�̎擾
    public SpellScroll GetSpell(string name, int level)
    {
        if (spellDic.ContainsKey(name))
        {
            SpellScroll spell = spellDic[name];
            SpellScroll spellInstance = GameObject.Instantiate(spell) as SpellScroll;

            return spellInstance;
        }
        else
            return null;
    }

    public SupportScroll GetSupport(string name)
    {
        if (supportDic.ContainsKey(name))
        {
            SupportScroll support = supportDic[name];
            SupportScroll supportInstance = GameObject.Instantiate(support) as SupportScroll;

            return supportInstance;
        }
        else
            return null;
    }
}
