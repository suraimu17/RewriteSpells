using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExaFlareGenerator : ISpellObjectGenerator
{
    [SerializeField] private float distance;
     public override void Generate(BaseSpellObject spellObject, SpellTriggerParameter param)
    {
        BaseSpellObject generated = spellObject.Clone();
        Vector3 direction = (param.target - param.user.transform.position).normalized;
        param.generatePosition += direction * distance;
        generated.transform.position = param.generatePosition;

        generated.Lunch(new SpellTriggerParameter(param.user, param.target, param.generatePosition));
    }
}
