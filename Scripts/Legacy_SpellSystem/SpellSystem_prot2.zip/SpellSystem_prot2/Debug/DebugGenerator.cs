using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugGenerator : ISpellObjectGenerator
{
    [SerializeField] private float distance;
    [SerializeField] private bool ignoreGeneratePosition;
    [SerializeField] private bool straight;


    public override void Generate(BaseSpellObject spellObject, SpellTriggerParameter param)
    {
        Vector3 vec = (param.target - param.user.transform.position).normalized;

        Vector3 right = Quaternion.Euler(0, 90f, 0) * vec;
        BaseSpellObject generated = spellObject.Clone();

        if (ignoreGeneratePosition)
        {
            generated.transform.position = param.user.transform.position + right * distance;
            Vector3 generatePos = generated.transform.position;
            generated.transform.position = generatePos;
            SpellTriggerParameter param2;
            if (!straight)
            {
                param2 = new SpellTriggerParameter(param.user, param.generatePosition, generated.transform.position);
            }
            else
            {

                param2 = new SpellTriggerParameter(param.user, param.target + right * distance, generated.transform.position);
            }
            generated.Lunch(param2);
        }
        else
        {
            generated.transform.position = param.generatePosition + right * distance;
            generated.Lunch(param);
        }


        Vector3 left = Quaternion.Euler(0, -90f, 0) * vec;
        BaseSpellObject generated2 = spellObject.Clone();
        if (ignoreGeneratePosition)
        {
            generated2.transform.position = param.user.transform.position + left * distance;
            Vector3 generatePos2 = generated2.transform.position;
            generated2.transform.position = generatePos2;
            SpellTriggerParameter param3;
            if (!straight)
            {
                param3 = new SpellTriggerParameter(param.user, param.generatePosition, generated2.transform.position);
            }
            else
            {

                param3 = new SpellTriggerParameter(param.user, param.target + left * distance, generated2.transform.position);
            }
            generated2.Lunch(param3);
        }
        else
        {
            generated2.transform.position = param.generatePosition + left * distance;
            generated2.Lunch(param);
        }
    }
}
