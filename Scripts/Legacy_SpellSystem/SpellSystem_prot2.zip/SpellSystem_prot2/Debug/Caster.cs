using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Inventories.Debugs;

public class Caster : MonoBehaviour
{
    public string spellName;
    public List<string> supportNames;

    //public SpellScroll spell;

    //���ۉ����ĕێ�
    private ICastable spell;

    [SerializeField] private DebugEquipment euip;
    [SerializeField] private string _tag;

    public void Start()
    {
        /*
        //���[�_�[����X�y�����擾
        SpellScroll spell = ScrollsLoader.loader.GetSpell(spellName, 0);
        if(spell == null)
        {
            return;
        }

        foreach(string name in supportNames)
        {
            SupportScroll support = ScrollsLoader.loader.GetSupport(name);
            if(support != null) spell.AddSupportScroll(support);
        }
        spell.Reload();

        this.spell = spell; //spell��ێ�
        */
    }

    public void Update()
    {
        /*if (this.GetNumInput()-1 >= 0)
        {
            if (euip._equips.ContainsKey(this.GetNumInput()-1)) spell = euip._equips[this.GetNumInput()-1];
            else spell = null;
            //Cast();
        }*/
    }

    public void Cast(int num)
    {
        if (this.GetNumInput() - 1 >= 0)
        {
            //if (euip._equips.ContainsKey(this.GetNumInput() - 1)) spell = euip._equips[this.GetNumInput() - 1];
            //else spell = null;
        }
        if (spell == null) return;

        // �J�[�\���ʒu���擾
        Vector3 mousePosition = Input.mousePosition;

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        if(Physics.Raycast(ray, out hit))
        {
            Vector3 target = hit.point;
            Vector3 generate = gameObject.transform.position;
            target.y = generate.y;
            gameObject.transform.rotation = Quaternion.LookRotation(target);
            SpellTriggerParameter param = new SpellTriggerParameter(gameObject, target, generate);
            param.tag = _tag;
            spell.Cast(param);
        }
    }
}



//�L���X�g�\�I�u�W�F�N�g�̃C���^�[�t�F�[�X
public interface ICastable
{
    public bool Cast(SpellTriggerParameter param);  //�L���X�g�֐� �߂�l�͎��s�ł��邩�ǂ���

    public void CancellCast();  //�L���X�g�𒆒f
}


public static class CasterExtend
{
    public static int GetNumInput(this Caster caster)
    {
        if (Input.GetKeyDown(KeyCode.Alpha0)) return 0;
        else if (Input.GetKeyDown(KeyCode.Alpha1)) return 1;
        else if (Input.GetKeyDown(KeyCode.Alpha2)) return 2;
        else if (Input.GetKeyDown(KeyCode.Alpha3)) return 3;
        else if (Input.GetKeyDown(KeyCode.Alpha4)) return 4;
        else if (Input.GetKeyDown(KeyCode.Alpha5)) return 5;
        else if (Input.GetKeyDown(KeyCode.Alpha6)) return 6;
        else if (Input.GetKeyDown(KeyCode.Alpha7)) return 7;
        else if (Input.GetKeyDown(KeyCode.Alpha8)) return 8;
        else if (Input.GetKeyDown(KeyCode.Alpha9)) return 9;
        return -1;
    }
}