using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Game.enemys;
using Game.players;

public class DebugAOE : BaseSpellObject
{
    protected override void LunchVirtual()
    {
    }

    private float time = 0;
    [SerializeField] private float maxTime;

    private bool removed = false;
    [SerializeField]private float damage;
    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;

        if(time >= maxTime && !removed)
        {
            OnRemove();
            removed = true;
        }
        if(time >= maxTime + 5.0f)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log(other);
        if (other.tag == "Search") return;
        if ((other.tag == "EnemyA" || other.tag == "EnemyB" || other.tag == "EnemyC"))
        {
            if (param.tag != "Enemy") return;
            EnemyStatus status = other.GetComponent<EnemyStatus>();
            if (status != null) status.DealDamage((int)damage);
        }
        else if (other.tag == "Player")
        {
            if (param.tag != "Player") return;
            GameObject playerManager = GameObject.Find("PlayerManager");
            PlayerHP hp = playerManager.GetComponent<PlayerHP>();
            if (hp != null) hp.HpMinus((int)damage);
        }
    }
}
