using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugMessage : BaseSpellObject
{
    [SerializeField] private string message;

    private void Start()
    {
        Debug.Log(message);
        Destroy(gameObject);
    }


    protected override void LunchVirtual()
    {
    }
}
