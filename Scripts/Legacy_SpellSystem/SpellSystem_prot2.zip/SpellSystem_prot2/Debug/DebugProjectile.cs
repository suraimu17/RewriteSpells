using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Game.enemys;
using Game.players;

public class DebugProjectile : BaseSpellObject
{
    private Rigidbody rigidbody;
    private Vector3 direction;
    [SerializeField] private float speed;
    [SerializeField] private float damage;

    //particle
    [SerializeField] private ParticleSystem muzzle;
    [SerializeField] private ParticleSystem explode;
    


    protected override void LunchVirtual()
    {
        rigidbody = GetComponent<Rigidbody>();
        direction = (param.target - param.generatePosition).normalized;
        if (!muzzle) return;
        GameObject go = Instantiate(muzzle.gameObject, transform.position, Quaternion.LookRotation(direction));
    }


    private void FixedUpdate()
    {
         //param�����ֈړ�
         rigidbody.MovePosition(gameObject.transform.position + direction * speed);
    }



    private void OnTriggerEnter(Collider other)
    {
        if (!hitFilter.Contains(other.gameObject))
        {
            if (other.tag == "Search") return;
            if ((other.tag == "EnemyA" || other.tag == "EnemyB" || other.tag == "EnemyC"))
            {
                if (param.tag != "Enemy") return;
                EnemyStatus status = other.GetComponent<EnemyStatus>();
                if (status != null) status.DealDamage((int)damage);
            }else if(other.tag == "Player")
            {
                if (param.tag != "Player") return;
                GameObject playerManager = GameObject.Find("PlayerManager");
                PlayerHP hp = playerManager.GetComponent<PlayerHP>();
                if (hp != null) hp.HpMinus((int)damage);
            }

            if (explode != null) Instantiate(explode.gameObject, transform.position, transform.rotation);
            OnRemove();
            Destroy(gameObject);  //hitFilter�Ɋ܂܂�Ȃ��Ȃ����,user�ȊO
        }
    }
}
