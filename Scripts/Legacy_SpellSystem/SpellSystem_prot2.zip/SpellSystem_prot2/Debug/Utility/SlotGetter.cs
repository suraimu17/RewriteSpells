using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlotGetter : MonoBehaviour
{
    [SerializeField] private SlotGrid2 grid2;
    [SerializeField] private SlotGrid3 grid3;

    
    public Slot[] GetSpellSlots()
    {
        return grid2.GetComponentsInChildren<Slot>();
    }

    public Slot[] GetSupportSlots()
    {
        return grid3.GetComponentsInChildren<Slot>();
    }
}
