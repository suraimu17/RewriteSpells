using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UISpellMediator : MonoBehaviour
{
    [Header("SlotsGetter")]
    [SerializeField] private SlotGetter getter;

    [Header("Scrolls")]
    [SerializeField] private List<SpellScroll> spells;
    [SerializeField] private List<SupportScroll> supports;

    [Header("Caster")]
    [SerializeField] private Caster caster;

    //spell��support�̑Ή��}�b�v
    private Dictionary<string, SpellScroll> spellDic = new Dictionary<string, SpellScroll>();
    private Dictionary<string, SupportScroll> supportDic = new Dictionary<string, SupportScroll>();


    private void Awake()
    {
        foreach (SpellScroll spell in spells)
        {
            if(spell.gameObject.name == "D_FireBall")
            {
                spellDic.Add("fabric", spell);
            }else if(spell.gameObject.name == "D_ExaFlare")
            {
                spellDic.Add("emeraldStaff", spell);
            }
        }
        foreach(SupportScroll support in supports)
        {
            if(support.gameObject.name == "D_A_ThunderBullet")
            {
                supportDic.Add("crystal", support);
            }else if(support.gameObject.name == "D_A_AddExplode")
            {
                supportDic.Add("Emerald", support);
            }
        }
    }


    public void Update()
    {
        if (Input.GetKey(KeyCode.Escape))
        {
            //���͂P�g�Ƃ���
            SpellScroll spell = null;
            foreach (Slot slot in getter.GetSpellSlots())
            {
                if (slot.MyItem == null) continue;
                if (!spellDic.ContainsKey(slot.MyItem.name)) continue;
                spell = spellDic[slot.MyItem.name];
                break;
            }
            if (spell == null) return;
            spell.ClearSupportScroll();

            foreach (Slot slot in getter.GetSupportSlots())
            {
                if (slot.MyItem == null) continue;
                if (!supportDic.ContainsKey(slot.MyItem.name)) continue;
                SupportScroll support = supportDic[slot.MyItem.name];
                spell.AddSupportScroll(support);
            }
            spell.Reload();
            //caster.spell = spell;
        }
    }
}
