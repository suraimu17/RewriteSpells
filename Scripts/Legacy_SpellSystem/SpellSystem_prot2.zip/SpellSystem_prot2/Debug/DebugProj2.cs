using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugProj2 : ISpellObjectGenerator
{
    [SerializeField] private int amount;
    [SerializeField] private float angle;
    [SerializeField] private bool removeMid;

    public override void Generate(BaseSpellObject spellObject, SpellTriggerParameter param)
    {
        Vector3 dir = (param.target - param.user.transform.position).normalized;

        float start_agl = -angle / 2;
        Vector3 dir_g = Quaternion.Euler(0, start_agl, 0) * dir;
        for(int i = 0; i < amount; i++)
        {
            if (removeMid && i == amount / 2)
            {
                dir_g = Quaternion.Euler(0, angle / (amount - 1), 0) * dir_g;
                continue;
            }

            BaseSpellObject generated = spellObject.Clone();
            generated.transform.position = param.generatePosition;

            Vector3 targets = param.generatePosition + dir_g * 10f;
            generated.Lunch(new SpellTriggerParameter(param.user, targets, param.generatePosition));

            dir_g = Quaternion.Euler(0, angle/(amount - 1), 0) * dir_g;
        }
    }
}
