using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//�g���K�[�ɕK�v�ȃp�����[�^
public class SpellTriggerParameter
{
    public SpellTriggerParameter(GameObject user, Vector3 target, Vector3 generatePosition)
    {
        this.user = user;
        this.target = target;
        this.generatePosition = generatePosition;
    }

    public readonly GameObject user;
    public readonly Vector3 target;
    public Vector3 generatePosition;
    public string tag;
}
