using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DefaultGenerator : ISpellObjectGenerator
{
    public override void Generate(BaseSpellObject spellObject, SpellTriggerParameter param)
    {
        BaseSpellObject generated = spellObject.Clone();
        generated.transform.position = param.generatePosition;
        generated.Lunch(param);
    }
}
