using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum SpellObjectControllerType
{
    GENERATE,
    REMOVE,
    UPDATE
}

public enum SpellObjectType
{
    NONE,
    DEBUG,
    PROJECTILE,
    AOE
}


public static class SpellObjectTypeExtension
{
    public static bool isSameType(this SpellObjectType type, BaseSpellObject spellObject)
    {
        return type == type.GetSpellObjectType(spellObject);
    }


    public static SpellObjectType GetSpellObjectType(this SpellObjectType type, BaseSpellObject spellObject)
    {
        switch (spellObject)
        {
            case DebugProjectile debug:
                return SpellObjectType.PROJECTILE;
            case DebugAOE debug:
                return SpellObjectType.AOE;
            default:
                return SpellObjectType.NONE;
        }
    }
}
