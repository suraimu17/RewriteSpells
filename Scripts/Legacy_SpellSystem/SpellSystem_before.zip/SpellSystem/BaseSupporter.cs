using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using System;
using SpellSystem.EventArgs;

namespace SpellSystem.Supporter
{
    public abstract class BaseSupporter
    {
        public BaseSupporter(ISpellObservable observable)
        {
            registSpellEvent(observable);
        }

        public abstract void registSpellEvent(ISpellObservable observable);
    }


    public interface ISpellObservable
    {
        public IObservable<SpellCastEvent> observableCast { get; }
        public IObservable<SpellRunEvent> observableRun { get; }
        public IObservable<SpellGenerateEvent> observableGenerate { get; }
        public IObservable<SpellRemoveEvent> observableRemove { get; }
        public IObservable<SpellHitEvent> observableHit { get; }

    }



    //�T�|�[�g���ɓ���̃X�y���𔭓��������ȃT�|�[�^�[
    public abstract class BaseTrrigerSupporter : BaseSupporter
    {
        private ITriggable triggable;

        public BaseTrrigerSupporter(ISpellObservable observable, ITriggable triggable) : base(observable)
        {
            this.triggable = triggable;
        }
    }

    public interface ITriggable
    {
        public void Trigger(Collider collider);
    }
}