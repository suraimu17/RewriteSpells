using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SpellSystem.Caster;

public class UnityInputProvider : MonoBehaviour, IInputProvider
{
    public bool GetCastKey()
    {
        return Input.GetKeyDown(KeyCode.Space);
    }
}
