using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SpellSystem.Spell.Object;

namespace SpellSystem.Spell
{
    public class DebugSpell : BaseSpell
    {
        GameObject go = (GameObject)Resources.Load("Projectile");

        public DebugSpell(float level) : base(level, 0, 0, 0)
        {
        }

        protected override void RunSpell(Collider collider)
        {
            Projectile projectile = go.GetComponent<Projectile>();
            Projectile p = GameObject.Instantiate(projectile, collider.transform.position, Quaternion.identity);
            p.Init(collider);
            p.Lunch(collider.transform.forward, 0.3f);
            generateEvent.collider = collider;
            generateEvent.ob = p;
            observerGenerate.OnNext(generateEvent);
        }

        private void OnHit(Collider collider, BaseSpellObject sobject)
        {

        }
    }
}
