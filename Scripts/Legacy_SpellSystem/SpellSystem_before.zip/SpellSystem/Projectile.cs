using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SpellSystem.Spell.Object;


[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(Collider))]
public class Projectile : BaseSpellObject
{
    bool lunch;
    Vector3 dir;
    float speed;
    Rigidbody rigidbody;

    public void Lunch(Vector3 direction, float speed)
    {
        lunch = true;
        dir = direction;
        this.speed = speed;
        rigidbody = GetComponent<Rigidbody>();
    }


    private void OnTriggerEnter(Collider other)
    {
    }


    private void Update()
    {
        if(lunch) rigidbody.MovePosition(rigidbody.position + dir.normalized * speed);
    }
}
