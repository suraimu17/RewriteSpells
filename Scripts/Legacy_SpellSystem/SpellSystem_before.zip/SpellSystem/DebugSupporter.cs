using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SpellSystem.Supporter;
using SpellSystem.EventArgs;
using SpellSystem.Spell;
using UniRx;
using System;
using SpellSystem.Spell.Object;

namespace SpellSystem.Supporter
{
    public class DebugSupporter : BaseSupporter
    {
        public DebugSupporter(ISpellObservable observable) : base(observable) { }

        public override void registSpellEvent(ISpellObservable observable)
        {
            IDisposable dipose = observable.observableCast.Subscribe(e => OnCastEvent(e));
            observable.observableGenerate.Where(e => e.ob is Projectile).Subscribe(e => OnGenerate(e));
        }

        private void OnGenerate(SpellGenerateEvent e)
        {
            Projectile p = (Projectile)GameObject.Instantiate(e.ob, e.collider.transform.position, Quaternion.identity);
            p.Init(e.collider);
            p.Lunch(e.collider.transform.right, 0.3f);
            Projectile p2 = (Projectile)GameObject.Instantiate(e.ob, e.collider.transform.position, Quaternion.identity);
            p2.Init(e.collider);
            p2.Lunch(-e.collider.transform.right, 0.3f);
        }

        private void OnHit(Collider collider, BaseSpellObject ob)
        {
            return;
        }

        private void OnCastEvent(SpellCastEvent e)
        {
            Debug.Log("CastEvent!");
            e.manaCost = 100;
        }
    }
}
