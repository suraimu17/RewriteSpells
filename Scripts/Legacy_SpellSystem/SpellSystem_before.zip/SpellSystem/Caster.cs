using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SpellSystem.Spell;
using SpellSystem.Supporter;


namespace SpellSystem.Caster
{
    //�r���҂̃R���|�[�l���g
    [RequireComponent(typeof(Collider))]        //Collider�K�{
    [RequireComponent(typeof(IInputProvider))]
    public class Caster : MonoBehaviour
    {
        //�}�i�\����
        public Mana mana { private set; get; }


        private Collider collider;                   //Collider
        private ICastable spell;                    //���@

        //�f�o�b�O�R�[�h
        private IInputProvider inputProvider;  


        //������
        private void Start()
        {
            mana = new Mana(100);
            collider = GetComponent<Collider>();
            inputProvider = GetComponent<IInputProvider>();

            BaseSpell spell = new DebugSpell(1);
            this.spell = spell;
            new DebugSupporter(spell);
        }


        //Update
        private void Update()
        {
            if (inputProvider.GetCastKey())
            {
                spell.Cast(collider, mana);
            }
        }
    }



    //�r���\�I�u�W�F�N�g�̃C���^�[�t�F�[�X
    public interface ICastable
    {
        public void Cast(Collider collider, Mana mana);
        public float castTime { get; }
    }



    //�f�o�b�O�C���^�[�t�F�[�X(?)
    public interface IInputProvider
    {
        public bool GetCastKey();
    }




    //�}�i�\����
    public struct Mana
    {
        public readonly float maxMana;  //�ő�}�i
        public float _currentMana;
        public float currentMana        //���݃}�i
        {
            set
            {
                if (value > maxMana)
                {
                    _currentMana = value;
                }
                else if (value < 0)
                {
                    _currentMana = 0;
                }
            }
            get { return _currentMana; }
        }

        //�R���X�g���N�^
        public Mana(float maxMana)
        {
            this.maxMana = maxMana;
            _currentMana = maxMana;
        }
    }
}
