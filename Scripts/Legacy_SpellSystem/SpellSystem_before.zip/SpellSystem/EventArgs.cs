using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SpellSystem.Caster;
using SpellSystem.Spell.Object;

namespace SpellSystem.EventArgs
{
    public abstract class SpellEvent
    {
        public Collider collider;
        public bool isCancel = false;
    }


    public class SpellCastEvent : SpellEvent
    {
        public float manaCost;
        public float delayTime;
        public float castTime;
        public float level;
    }

    public class SpellRunEvent : SpellEvent
    {

    }

    public class SpellGenerateEvent : SpellEvent
    {
        public BaseSpellObject ob;
    }


    public class SpellRemoveEvent : SpellEvent 
    {

    }



    public class SpellHitEvent : SpellEvent 
    {

    }
}
