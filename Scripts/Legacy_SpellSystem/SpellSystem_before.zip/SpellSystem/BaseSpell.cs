using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SpellSystem.EventArgs;
using SpellSystem.Supporter;
using SpellSystem.Caster;
using System;
using UniRx;

namespace SpellSystem.Spell
{
    public abstract class BaseSpell : ICastable, ITriggable, ISpellObservable
    {
        //�T�u�W�F�N�g�Q
        private Subject<SpellCastEvent> subjectCast = new Subject<SpellCastEvent>();
        private Subject<SpellRunEvent> subjectRun = new Subject<SpellRunEvent>();
        private Subject<SpellGenerateEvent> subjectGenerate = new Subject<SpellGenerateEvent>();
        private Subject<SpellRemoveEvent> subjectRemove = new Subject<SpellRemoveEvent>();
        private Subject<SpellHitEvent> subjectHit = new Subject<SpellHitEvent>();


        //Observable(�T�u�N���X�Ŏg�p)
        protected IObserver<SpellCastEvent> observerCast { get { return subjectCast; } }
        protected IObserver<SpellRunEvent> observerRun { get { return subjectRun; } }
        protected IObserver<SpellGenerateEvent> observerGenerate { get { return subjectGenerate; } }
        protected IObserver<SpellRemoveEvent> observerRemove { get { return subjectRemove; } }
        protected IObserver<SpellHitEvent> observerHit { get { return subjectHit; } }


        //�C�x���g�o�^�@�\�̎���
        public IObservable<SpellCastEvent> observableCast => subjectCast;
        public IObservable<SpellRunEvent> observableRun => subjectRun;
        public IObservable<SpellGenerateEvent> observableGenerate => subjectGenerate;
        public IObservable<SpellRemoveEvent> observableRemove => subjectRemove;
        public IObservable<SpellHitEvent> observableHit => subjectHit;


        //�C�x���g
        protected SpellCastEvent castEvent;
        protected SpellRunEvent runEvent;
        protected SpellGenerateEvent generateEvent;
        protected SpellRemoveEvent removeEvent;
        protected SpellHitEvent hitEvent;


        //�t�B�[���h
        protected readonly float level;
        protected readonly float manaCost;
        protected readonly float delayTime;
        public float castTime { get; protected set; }   //�L���X�g�^�C��


        //�R���X�g���N�^
        public BaseSpell(float level, float manaCost, float delayTime, float castTime)
        {
            this.level = level;
            this.manaCost = manaCost;
            this.delayTime = delayTime;
            this.castTime = castTime;

            castEvent = new SpellCastEvent();
            runEvent = new SpellRunEvent();
            generateEvent = new SpellGenerateEvent();
            removeEvent = new SpellRemoveEvent();
            hitEvent = new SpellHitEvent();
        }



        //�}�i����㖂�@�̔���
        public void Cast(Collider collider, Mana mana) 
        {
            //�C�x���g���e����
            castEvent.collider = collider;
            castEvent.level = level;
            castEvent.manaCost = manaCost;
            castEvent.delayTime = delayTime;
            castEvent.castTime = castTime;
            observerCast.OnNext(castEvent);

            if (!castEvent.isCancel)
            {
                //�}�i����
                if(mana.currentMana >= castEvent.manaCost)
                {
                    mana.currentMana -= castEvent.manaCost;
                    RunSpell(collider); //�X�y���̔���
                }
            }
        }


        //���ۂ͖��@�̔����̂� �֘A�C�x���g����(TriggerSupporter�ɗv�������ӂ�܂�)
        public void Trigger(Collider collider)
        {
            RunSpell(collider);
        }


        //���@�̏���
        protected abstract void RunSpell(Collider collider);
    }
}